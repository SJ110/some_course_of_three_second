#include<stdio.h>
#include<sys/syscall.h>
#include<unistd.h>
int main(int argc,char*argv[]){
   long a=syscall(387,argv[1],argv[2]);
   printf("this is copy,return %ld\n",a);
   return 0;
}
