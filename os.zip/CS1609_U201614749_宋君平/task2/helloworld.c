#include<stdio.h>
#include<unistd.h>
#include<sys/syscall.h>
int main(){
  long a=syscall(388);
  printf("this is %ld\n",a);
  return 0;
}
