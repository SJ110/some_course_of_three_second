#include"header.h"
#include<wait.h>
#include<gtk/gtk.h>

#define WINDOW_WIDTH 450
#define WINDOW_HEIGHT 300
#define RE_FEQ1 1000 
#define RE_FEQ2 1000
#define RE_FEQ3 1000

 //��ʾ��ǰʱ��  
gboolean refresh_time(gpointer label){
	time_t times;
	struct tm *time_buf;
	time(&times);
	time_buf=localtime(&times); //localtime ��1900������ 
	
	//��ȡ��ǰʱ��
	gchar*text_day=g_strdup_printf("<span font_desc='48'>%04d.%02d.%02d</span>",\
	1900+time_buf->tm_year,time_buf->tm_mon+1,time_buf->tm_mday);   //month+1   font_desc�����С 
	gchar*text_time=g_strdup_printf("<span font_desc='32'>%02d:%02d:%02d</span>",\
	time_buf->tm_hour,time_buf->tm_min,time_buf->tm_sec);  //��ǰʱ��
	gchar*text_data=g_strdup_printf("\n%s\n\n%s\n",text_day,text_time);
	
	gtk_label_set_markup(GTK_LABEL(label),text_data); //���ð�ɫ���� 
	return TRUE;
} 


//���cpu
/*gboolean refresh_cpu_useage(gpointer label){
	FILE*fp;
	char buf[128];
	char cpu[5];
	long int user,nice,sys,idle,iowait,irq,softirq;  //cpu��Ϣ
	long int all1,all2,idle1,idle2;
	float useage;
	if((fp=fopen("/proc/stat","r"))==NULL)  {
		printf("can`t open file\n");
		exit(0);
	}
	fgets(buf,sizeof(buf),fp);
	sscanf(buf,"%s%ld%ld%ld%ld%ld%ld%ld",cpu,&user,&nice,&sys,&idle,&iowait,&irq,&softirq);
	all1=user+nice+sys+idle+iowait+irq+softirq;
	idle1=idle;
/*	rewind(fp); //�ص��ļ��ײ�
	//�ڶ��ζ�ȡ����
	sleep(1);
	fgets(buf,sizeof(buf),fp);
	sscanf(buf,"%s,%ld%ld%ld%ld%ld%ld%ld",cpu,&user,&nice,&sys,&idle,&iowait,&irq,&softirq);
	all2=user+nice+sys+idle+iowait+irq+softirq;
	idle2=idle;*/
	/*fclose(fp);
	gchar*text_cpu=g_strdup_printf("<span font_desc='48'>(%ld-%ld)/%ld=</span>",\
	all1,idle1,all1);
	useage=(float)(all1-idle1)/all1*100;
	gchar*text_use=g_strdup_printf("<span font_desc='32'>%0.2f%%</span>",useage);
	gchar*text_data=g_strdup_printf("\n%s\n\n%s",text_cpu,text_use);
	
	gtk_label_set_markup(GTK_LABEL(label),text_data);
	return TRUE;
}*/

//0-9
gboolean refresh_number(gpointer label){
        static int num=0;
        gchar*text_old=g_strdup_printf("<span font_desc='48'>now the number is %d</span>",num);
        num++;
        if(num==10){
            num=0;
        }
        gchar*text_data=g_strdup_printf("\n%s\n",text_old);
      //  num++;
        gtk_label_set_markup(GTK_LABEL(label),text_data);
        return TRUE;
}
//�ۼ����
gboolean refresh_sum(gpointer label){
	static int sum=0;
	static int add=1;
	gchar*text_old=g_strdup_printf("<span font_desc='48'>%d+%d=</span>",sum,add);
	sum+=add;
	gchar*text_new=g_strdup_printf("<span font_desc='32'>%d</span>",sum);
	add++;
	if(add==1000) {
		add=1;sum=0;
	}
	gchar*text_data=g_strdup_printf("\n%s\n\n%s\n",text_old,text_new);
	
	gtk_label_set_markup(GTK_LABEL(label),text_data);
	return TRUE;
} 


int main(int argc,char*argv[]){
	int pid1,pid2;
	int wait_tmp;
	
	switch(pid1=fork()){
		case -1:  printf("pid1 fork error\n"); exit(0);
		//pid1 ��ʾʱ�� 
		case 0:    
		gtk_init(&argc,&argv);//��ʼ��
		GtkWidget* window1=gtk_window_new(GTK_WINDOW_TOPLEVEL);//�½����㴰���б߿�
	    g_signal_connect(G_OBJECT(window1), "delete_event", G_CALLBACK(gtk_main_quit), NULL);   //�رմ���ʱ�˳�ѭ�� 
	    gtk_window_set_title(GTK_WINDOW(window1),"window1 show time"); //��������
		//���ô����ڲ���Ϣ
		GtkWidget* label1=gtk_label_new(NULL);  
		gtk_container_add(GTK_CONTAINER(window1), label1);  //��label1���봰��
		gint s1 = g_timeout_add(RE_FEQ1, refresh_time, (void *)label1); //1sˢ��һ�δ��� 
		gtk_widget_set_size_request(window1, WINDOW_WIDTH, WINDOW_HEIGHT); //���ô��ڴ�С
		gtk_widget_show_all(window1);//��ʾ����
		gtk_main(); //����ѭ�� ֱ�� gtk_main_quitʱ�˳�
		printf("window1 closed.\n");
		exit(0); 
		
		default:
			switch(pid2=fork()){
				case -1: printf("pid2 fork error.\n");exit(0);
				//pid2 ��ʾcpu������  
				case 0:
				gtk_init(&argc,&argv);//��ʼ��
		        GtkWidget* window2=gtk_window_new(GTK_WINDOW_TOPLEVEL);//�½����㴰���б߿�	
		        g_signal_connect(G_OBJECT(window2), "delete_event", G_CALLBACK(gtk_main_quit), NULL);
                gtk_window_set_title(GTK_WINDOW(window2), "window2 show cpu useage");
                
                //�����ڲ���Ϣ
				GtkWidget *label2 = gtk_label_new(NULL);
                gtk_container_add(GTK_CONTAINER(window2), label2);
                gint s2 = g_timeout_add(RE_FEQ2, refresh_number, (void *)label2);  //2s
                gtk_widget_set_size_request(window2,WINDOW_WIDTH,WINDOW_HEIGHT);
                gtk_widget_show_all(window2);
                gtk_main();
                printf("window2 closed.\n");
                exit(0);
                default:
                	//parent pid show 1add to 100
                gtk_init(&argc,&argv);
                GtkWidget* window3=gtk_window_new(GTK_WINDOW_TOPLEVEL);
                g_signal_connect(G_OBJECT(window3),"delet_event",G_CALLBACK(gtk_main_quit),NULL);
                gtk_window_set_title(GTK_WINDOW(window3), "window3 show 1 add to 100");
                //�����ڲ���Ϣ
				GtkWidget *label3 = gtk_label_new(NULL);
				gtk_container_add(GTK_CONTAINER(window3),label3);
				gint s3=g_timeout_add(RE_FEQ3,refresh_sum,(void*)label3); //3s
				gtk_widget_set_size_request(window3,WINDOW_WIDTH,WINDOW_HEIGHT);
                gtk_widget_show_all(window3);
                gtk_main();
                printf("window3 closed.\n");
                waitpid(pid1,&wait_tmp,0);
                waitpid(pid2,&wait_tmp,0);
                return 0;
			}
	}
}
