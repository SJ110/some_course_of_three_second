#include<sys/types.h>
#include<sys/stat.h>
#include<string.h>
#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>

int main(){
	char buf[1024],get[1024];
	int fd;
	memset(buf,0,sizeof(buf));
	memset(get,0,sizeof(get));
	printf("enter a string to put in mydriver:");
	gets(get);
	fd=open("/dev/mydriver",O_RDWR, S_IRUSR|S_IWUSR);
	if(fd>0){
		read(fd,&buf,sizeof(buf));
		printf("now the message in the driver is:%s\n",buf);
		write(fd,&get,sizeof(get));
		read(fd,&buf,sizeof(buf));  //��������Ϣ�����豸 
		printf("then it changes to:%s\n",buf);
		
	}else{
		printf("read error\n");
		exit(0);
	}
	close(fd);
	return 0;
}
