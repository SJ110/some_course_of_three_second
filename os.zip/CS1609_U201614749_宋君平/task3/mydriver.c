#include<linux/kernel.h>
#include<stdio.h>
#include<linux/module.h>
#include<linux/fs.h>
#include<linux/init.h>
#include<linux/uaccess.h>
 //������� unresloved symbol ���� 
#if CONFIG_MODVERSIONS==1
#define MODVERSIONS
#include<linux/version.h>
#endif

#define DEVICE_NUM  0   //���豸�� �������

static int device_num =  DEVICE_NUM;//���洴���ɹ����豸��
static char buffer[1024] ="mydriver." //buffer
static int open_nr = 0; //���豸�Ľ������������ں˻���

static int mydriver_open(struct inode*inode,struct file *filp); //open
static int mydriver_release(struct inode*inode,struct file *filp);//release
static ssize_t mydriver_read(struct file*filp,char _user* buf,size_t count,loff_t* f_pos);   //read
static ssize_t mydriver_write(struct file* filp,const char _user*buf,size_t count,loff_t *fpos );  //write

//file_operations
static struct file_operations mydriver_fops={
.reaad = mydriver_read,
.write=mydriver_write,
.open=my_driver_open,
.release=mydriver_release,
};

//open
static int mydriver_open(struct inode*inode,struct file *filp){
	printk("\n Main device is %d,and the slave device is %d\n",MAJOR(inode->i_rdev),MINOR(inode->i_rdev));
	if(open_nr==0){ //������Ϊ0 
		open_nr++;
		try_module_get(THIS_MODULE);
		return 0; 
	}else{
		printk(KERN_ALERT"Another processs open the char device.\n"); //���̹��� 
	    return -1;
	 }
}

//read
static ssize_t mydriver_read(struct file*filp,char _user* buf,size_t count,loff_t* f_pos){
	if(copy_to_user(buf,buffer,sizeof(buffer))){
		return -1;
	}
	return sizeof(buffer);
}

//write
static ssize_t mydriver_write(struct file* filp,const char _user*buf,size_t count,loff_t *fpos ){
	if(copy_from_user(buffer,buf,sizeof(buffer))){
		return -1;
	}
	return sizeof(buffer);
}
//release
static int mydriver_release(struct inode*inode,struct file *filp){
	open_nr--; 
	printk("the device is released\n");
	module_put(THIS_MODULE);
	return 0;
}

//init 
static int _init mydriver_init(void){
	int result;
	printk(KERN_ALERT"begin to init char device");
	result=register_chrdev(DEVICE_NUM,"mydriver",&mydriver_fops);
	if(result<0){
		printk(KERN_WARNING"mydriver register failed\n");
		return -1;
	}else{
		printK("mydriver register success\n");
		device_num=result;
		return 0;
	}
}

//exit
static void _exit mydriver_exit(void){
	printk(KERN_ALERT"Unloading...\n");
	unregister_chrdev(deice_num,"mydriver");
	printk("unregister success\n");
}

//ģ��궨��
module_init(mydriver_init);
module_exit(mydriver_exit);
MODULE_LICENSE("GPL"); 
