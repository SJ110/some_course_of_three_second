#include<gtk/gtk.h>
#include"header.h"
#define HEIGHT 600
#define WIDTH 500
char*txt_pid=NULL;
GtkWidget *label1;
GtkWidget *cpu_curve;
GtkWidget *clist;
GtkWidget *entry;
int cpu_curve_start=20;
float cpu_ratio_data[120];
float cpu_ratio=0;
//gtk_clist_set_column_title(GTK_CLIST*clist,gint column,gchar *title);

void get_cpu_name(char *buf);
void get_cpu_type(char *buf);
void get_cpu_MZ(char *buf);
void get_address_sizes(char *buf);
void get_os_type(char *buf);
void get_os_version(char *buf);
gboolean cpu_usage(gpointer label);//void cpu_usage();
void select_row_callback(GtkWidget* clist,gint row,gint column,GdkEventButton*event,gpointer data);
//void refresh_use(GtkWidget *clist);
//void get_proc_info(GtkWidget *clist,int *p,int *q,int *r,int *s);
gboolean draw_cpu_curve(gpointer widget);
gboolean cpu_curve_callback(GtkWidget *widget, GdkEventExpose *event, gpointer data);
void refresh_proc(void);
//获取cpu名称

 //function
void get_cpu_name(char *buf){
	int fd;
	int i=0;
	char *pos=NULL;
	char buf_0[1024]; 
	char readbuf[2048];
	fd=open("/proc/cpuinfo",O_RDONLY);
	read(fd,readbuf,sizeof(readbuf));
	close(fd);
	pos=strstr(readbuf,"model name");
	while(*pos!=':'){
		pos++;
	}
	pos+=2;
	while(*pos!='\n'){
		buf_0[i]=*pos;
		i++;
		pos++;
	}
	buf_0[i]='\0';
        strcpy(buf,buf_0);
	//return buf;
} 

//get cputype
void get_cpu_type(char *buf){
	int fp;
	int i=0;
	char *pos=NULL;
	static char buf_1[1024];
	char readbuf[2048];
	fp=open("/proc/cpuinfo",O_RDONLY);
	read(fp,readbuf,sizeof(readbuf));
	close(fp);
	pos=strstr(readbuf,"cache size");
	while(*pos!=':')pos++;
	pos+=2;
	while(*pos!='\n'){
		buf_1[i]=*pos;
		i++;pos++;
	} 
	buf_1[i]='\0';
        strcpy(buf,buf_1);
	//return buf_1;
}

//get cpu MZ
void get_cpu_MZ(char *buf){
	int fp;
	int i=0;
	char *pos=NULL;
	static char buf_2[1024];
	char readbuf[2048];
	fp=open("/proc/cpuinfo",O_RDONLY);
	read(fp,readbuf,sizeof(readbuf));
	close(fp);
	pos=strstr(readbuf,"cpu MHz");
	while(*pos!=':')pos++;
	pos+=2;
	while(*pos!='\n'){
		buf_2[i]=*pos;
		i++;pos++;
	} 
	buf_2[i]='\0';
        strcpy(buf,buf_2);	
//return buf_2;
}

//get adress sizes
void get_address_sizes(char *buf){
	int fp;
	int i=0;
	char *pos=NULL;
	static char buf_3[1024];
	char readbuf[2048];
	fp=open("/proc/cpuinfo",O_RDONLY);
	read(fp,readbuf,sizeof(readbuf));
	close(fp);
	pos=strstr(readbuf,"address sizes");
	while(*pos!=':')pos++;
	pos+=2;
	while(*pos!='\n'){
		buf_3[i]=*pos;
		i++;pos++;
	} 
	buf_3[i]='\0';
        strcpy(buf,buf_3);	
//return buf_3;
}

//get os type
void get_os_type(char *buf){
	int fp;
	int i=0;
//	char *pos=buf;
	static char buf_4[1024];
	char readbuf[256];
	fp=open("/etc/issue",O_RDONLY);
	read(fp,readbuf,sizeof(readbuf));
	close(fp);
    while(readbuf[i]!='\n'){
    	buf_4[i]=readbuf[i];
    	i++;
	}
	buf_4[i]='\0';
        strcpy(buf,buf_4);
	//return buf_4;
}

//get_os_version
void get_os_version(char *buf){
	int fp;
	int i=0;
//	char *pos=buf;
	static char buf_5[1024];
	char readbuf[25];
	fp=open("/etc/issue",O_RDONLY);
	read(fp,readbuf,sizeof(readbuf));
	close(fp);
    while(i<=21){
    	buf_5[i]=readbuf[i];
    	i++;
	}
	buf_5[i]='\0';
        strcpy(buf,buf_5);
	//return buf_5;
}

//get cpuuseage
gboolean cpu_usage(gpointer label1){
	int fd;
	char cpu[5];
	char buff[1000];
	char s[1000];
	long user,nice,sys,idle,iowait,irq,softirq;
	long s1,idle1;
	//float useage;
	while(1){
		fd=open("/proc/stat",O_RDONLY);
		read(fd,buff,sizeof(buff));
                close(fd);
		sscanf(buff,"%s%ld%ld%ld%ld%ld%ld%ld",cpu,&user,&nice,&sys,&idle,&iowait,&irq,&softirq);
		idle1=idle;
		s1=user+nice+idle+iowait+irq+softirq+sys;
		//memset(buff,0,sizeof(buff));//重置缓冲区
		cpu_ratio=(float)(s1-idle1)/s1*100;
		sprintf(s,"cpu useage is %f%%:",cpu_ratio);
		//gdk_threads_enter();
		gtk_label_set_text(GTK_LABEL(label1),s);
		//gdk_threads_leave();
                return TRUE;
	}
} 



//show pid 
void read_stat(char (*info)[1024], char *stat_file) {
  /*
   * stat file format:
   * 
   * pid (name) status ppid ......(13 data) priority (4 data) memory
   */
  int pos;

  /* Get pid */
  for (pos = 0; pos < 1024; pos++) {
    if (stat_file[pos] == ' ')
      break;
  }
  stat_file[pos] = '\0';
  strcpy(info[0], stat_file);
  stat_file += pos;
  stat_file += 2;

  /* Get name */
  for (pos = 0; pos < 1024; pos++) {
    if (stat_file[pos] == ')')
      break;
  }
  stat_file[pos] = '\0';
  strcpy(info[1], stat_file);
  stat_file += pos;
  stat_file += 2;

  /* Get status */
  for (pos = 0; pos < 1024; pos++) {
    if (stat_file[pos] == ' ')
      break;
  }
  stat_file[pos] = '\0';
  strcpy(info[3], stat_file);
  stat_file += pos;
  stat_file += 1;

  /* Get ppid */
  for (pos = 0; pos < 1024; pos++) {
    if (stat_file[pos] == ' ')
      break;
  }
  stat_file[pos] = '\0';
  strcpy(info[2], stat_file);
  stat_file += pos;
  stat_file += 1;

  /* Get priority */
  int i;
  for (i = 0, pos = 0; pos < 1024; pos++) {
    if (stat_file[pos] == ' ')
      i++;
    if (i == 13)
      break;
  }
  stat_file[pos] = '\0';
  stat_file += pos;
  stat_file += 1;
  for (pos = 0; pos < 1024; pos++) {
    if (stat_file[pos] == ' ')
      break;
  }
  stat_file[pos] = '\0';
  strcpy(info[4], stat_file);
  stat_file += pos;
  stat_file += 1;

  /* Get memory use */
  for (i = 0, pos = 0; pos < 1024; pos++) {
    if (stat_file[pos] == ' ')
      i++;
    if (i == 4)
      break;
  }
  stat_file[pos] = '\0';
  stat_file += pos;
  stat_file += 1;
  for (pos = 0; pos < 1024; pos++) {
    if (stat_file[pos] == ' ')
      break;
  }
  stat_file[pos] = '\0';
 // char buf[1024];
  //sprintf(buf, "%d KB\0", abs(atoi(stat_file)) / 1024);
  strcpy(info[5], stat_file);
}

void get_process_info(void) {
  DIR *dir;
  struct dirent *dir_info;
  int fd;
  char pid_file[1024];
  char stat_file[1024];
  char *one_file = NULL;
  char info[6][1024];
  gchar *txt[6];
  gint process_num=0;

  /* Set clist column title */
  gtk_clist_set_column_title(GTK_CLIST(clist), 0, "PID");
  gtk_clist_set_column_title(GTK_CLIST(clist), 1, "Name");
  gtk_clist_set_column_title(GTK_CLIST(clist), 2, "PPID");
  gtk_clist_set_column_title(GTK_CLIST(clist), 3, "State");
  gtk_clist_set_column_title(GTK_CLIST(clist), 4, "Priority");
  gtk_clist_set_column_title(GTK_CLIST(clist), 5, "Memory use");

  /* Set clist column width */
  gtk_clist_set_column_width(GTK_CLIST(clist), 0, 50);
  gtk_clist_set_column_width(GTK_CLIST(clist), 1, 125);
  gtk_clist_set_column_width(GTK_CLIST(clist), 2, 50);
  gtk_clist_set_column_width(GTK_CLIST(clist), 3, 50);
  gtk_clist_set_column_width(GTK_CLIST(clist), 4, 50);
  gtk_clist_set_column_width(GTK_CLIST(clist), 5, 75);
  gtk_clist_column_titles_show(GTK_CLIST(clist));

  /* Read proc info */
  dir = opendir("/proc");
  process_num = 0;
  while (dir_info = readdir(dir)) {
    /*
     * If start with number, then read it
     */
    if ((dir_info->d_name)[0] >= '0' && ((dir_info->d_name)[0]) <= '9') {
      sprintf(pid_file, "/proc/%s/stat", dir_info->d_name);
      fd = open(pid_file, O_RDONLY);
      read(fd, stat_file, 1024);
      close(fd);
      one_file = stat_file;
      read_stat(info, one_file);
      for (int i = 0; i < 6; i++)
        txt[i] =info[i];
      gtk_clist_append(GTK_CLIST(clist), txt);
      process_num++;
    }
  }
  closedir(dir);
}


//main
int main(int argc,char*argv[]){
	char buffer1[10];
	GtkWidget *window;
        GtkWidget*notebook;
        char title[100];
        GtkWidget* hbox;
        GtkWidget* vbox;
        GtkWidget* cpu_use;
        GtkWidget* label1;
        GtkWidget* label;
        GtkWidget *scrolled_window;
        GtkWidget *button1;
        gtk_init(&argc,&argv);
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);//顶层有边框窗口 500 400
	gtk_widget_set_size_request(window,HEIGHT,WIDTH);
	gtk_window_set_title(GTK_WINDOW(window),"proc info"); 
        g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(gtk_main_quit),NULL); //click to end of main
        gtk_container_set_border_width(GTK_CONTAINER(window), 10);//border
	
	// 创建笔记本控件
        notebook=gtk_notebook_new();
	gtk_container_add(GTK_CONTAINER(window),notebook); //加入窗口中 
	gtk_notebook_set_tab_pos(GTK_NOTEBOOK(notebook),GTK_POS_TOP); //set position

//	gtk_widget_show(notebook);
	 
	//first page
        sprintf(title,"CPU USE");
        vbox = gtk_vbox_new(FALSE, 0);

  /* Creat frame to show curve of CPU use */
  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, FALSE, 5);
  cpu_use = gtk_frame_new("CPU Use");
  gtk_container_set_border_width(GTK_CONTAINER(cpu_use), 5);
  gtk_widget_set_size_request(cpu_use, 520, 300);
  gtk_box_pack_start(GTK_BOX(hbox), cpu_use, TRUE, FALSE, 5);

  hbox = gtk_hbox_new(FALSE, 0);
  label1 = gtk_label_new("");
  gtk_box_pack_start(GTK_BOX(hbox), label1, TRUE, FALSE, 5);
  g_timeout_add(1000, (GtkFunction)cpu_usage, (gpointer)label1);
  gtk_widget_set_size_request(hbox, 550, 30);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, FALSE, 5);    
  
//draw the curve
        cpu_curve=gtk_drawing_area_new(); //draw
        gtk_widget_set_size_request(cpu_curve, 0, 0);
        g_signal_connect(G_OBJECT(cpu_curve), "expose_event", G_CALLBACK(cpu_curve_callback), NULL); //to finish
        gtk_container_add(GTK_CONTAINER(cpu_use), cpu_curve);//add curve to page 1


        label = gtk_label_new(title);
        gtk_notebook_append_page(GTK_NOTEBOOK(notebook), vbox, label); //add to notebook




//pid page
         sprintf(title, "Process");
         vbox = gtk_vbox_new(FALSE, 0);
      // GtkWidget* 
	//int p=0,q=0,s=0,r=0;
	char bufferf1[1000];   
	hbox=gtk_hbox_new(FALSE,5);//all use
        scrolled_window=gtk_scrolled_window_new(NULL,NULL);
        gtk_widget_set_size_request(scrolled_window,400,300);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),GTK_POLICY_AUTOMATIC,GTK_POLICY_AUTOMATIC);
      

        clist=gtk_clist_new(6); //0 1 2  3 4
        get_process_info();
   	//get_proc_info(clist,&p,&q,&r,&s);
   	gtk_signal_connect(GTK_OBJECT(clist),"select_row",GTK_SIGNAL_FUNC(select_row_callback),NULL);
    gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolled_window),clist);
    //gtk_box_pack_start(GTK_BOX(vbox),scrolled_window,TRUE,TRUE,5); 	
   /// hbox=gtk_hbox_new(FALSE,5);
 
  /*  entry = gtk_entry_new();
    gtk_entry_set_max_length(GTK_ENTRY(entry), 0);
    button1 = gtk_button_new_with_label("Refresh");
    g_signal_connect(G_OBJECT(button1), "clicked", G_CALLBACK(refresh_proc), NULL);
    gtk_widget_set_size_request(entry,100,30); //size
    gtk_widget_set_size_request(button1, 80, 30);
    gtk_box_pack_start(GTK_BOX(hbox), button1, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(vbox),entry,FALSE,FALSE,5);
    
 
        label = gtk_label_new(title); //page title
	//label=gtk_label_new("process");
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook),vbox,label); */ 	

	//char bufferf1[1000];   
	//hbox=gtk_hbox_new(FALSE,5);
       // scrolled_window=gtk_scrolled_window_new(NULL,NULL);
       // gtk_widget_set_size_request(scrolled_window,400,400);
	//gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW     (scrolled_window),GTK_POLICY_AUTOMATIC,GTK_POLICY_AUTOMATIC);
   // GtkWidget*clist=gtk_clist_new(6); //0 1 2  3 4
    
   	//get_proc_info(clist,&p,&q,&r,&s);
       // get_process_info();
   	//gtk_signal_connect(GTK_OBJECT(clist),"select_row",GTK_SIGNAL_FUNC(select_row_callback),NULL);
       // gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolled_window),clist);
    gtk_box_pack_start(GTK_BOX(hbox),scrolled_window,TRUE,TRUE,5); 	
    vbox=gtk_vbox_new(FALSE,5);
    GtkWidget *frame=gtk_frame_new("");
    gtk_widget_set_size_request(frame,100,100); //size
    //sprintf(bufferf1,"All process: %d\n\nRunning: %d \n\nSleeping:%d\n\nZombied: %d\n",p,q,r,s);
    label = gtk_label_new("click blow to refresh"); //new label
    //add to window
    gtk_container_add(GTK_CONTAINER(frame),label);
    gtk_box_pack_start(GTK_BOX(vbox),frame,FALSE,FALSE,10);
    
    GtkWidget *button2=gtk_button_new_with_label("refresh");
    //click to refesh
    g_signal_connect_swapped(G_OBJECT(button2),"clicked",G_CALLBACK(refresh_proc),clist); 
	gtk_box_pack_start(GTK_BOX(vbox),button2,FALSE,FALSE,10);
    gtk_box_pack_start(GTK_BOX(hbox),vbox,TRUE,TRUE,5);
    gtk_widget_show_all(hbox); //show
	label=gtk_label_new("process");
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook),hbox,label); 
	
         //third page
	//ubuntu info
	char buf1[256],buf2[256],buf3[256],buf4[256],buf5[256],buf6[256],buffer[256],buffers1[256],buffers2[256];
        sprintf(title,"ubuntu");
	hbox=gtk_hbox_new(TRUE,0);

	gtk_container_add(GTK_CONTAINER(window),hbox);
	GtkWidget*frame1=gtk_frame_new("core info");
	gtk_container_set_border_width(GTK_CONTAINER(frame1),10); //add to window
	get_cpu_name(buf1);
        get_cpu_type(buf2);
        get_cpu_MZ(buf3);
        get_address_sizes(buf4);
    gtk_widget_set_size_request(frame1,300,180);
    GtkWidget*frame2=gtk_frame_new("about");
    gtk_container_set_border_width(GTK_CONTAINER(frame2),10);
    gtk_widget_set_size_request(frame2,300,180);
     
    sprintf(buffers1,"\tCPU name :%s\n\tcache size :%s\n\t频率 ：%sMHZ\n\taddress sizes ：%s\n",buf1,buf2,buf3,buf4);
        GtkWidget*label2=gtk_label_new(buffers1);
	gtk_container_add(GTK_CONTAINER(frame1),label2);
	//gtk_widget_show(frame1);
        gtk_box_pack_start(GTK_BOX(hbox),frame1,FALSE,FALSE,0);
        get_os_type(buf5);
        get_os_version(buf6);
	sprintf(buffers2,"\t os type:%s \n \n \t 版本：%s \n \n \n\tCopyright@2017song",buf5,buf6);
	GtkWidget*label3=gtk_label_new(buffers2);
	//add
	gtk_container_add(GTK_CONTAINER(frame2),label3);
	gtk_box_pack_start(GTK_BOX(hbox),frame2,FALSE,FALSE,0);
        label = gtk_label_new(title); 
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook),hbox,label);

	//show all
	gtk_widget_show_all(window);
	gtk_main();
	return 0;
	 
}  
/********call back********/
void select_row_callback(GtkWidget* clist,gint row,gint column,GdkEventButton*event,gpointer data){
	gtk_clist_get_text(GTK_CLIST(clist),row,0,&txt_pid);
       // gtk_entry_set_text(GTK_ENTRY(entry), (gchar *)txt_pid);
	//printf("%s\n",txt_pid);
        return;
}

gboolean cpu_curve_callback(GtkWidget *widget, GdkEventExpose *event, gpointer data) {
  static int flag = 0;
  draw_cpu_curve((gpointer)widget);
  if (flag == 0) {
    g_timeout_add(1000, (GtkFunction)draw_cpu_curve, (gpointer)widget);
    flag = 1;
  }
  return TRUE;
}
//callback to refresh
void refresh_proc(void) {
  gtk_clist_freeze(GTK_CLIST(clist));
  gtk_clist_clear(GTK_CLIST(clist));
  get_process_info();
  gtk_clist_thaw(GTK_CLIST(clist));
  gtk_clist_select_row(GTK_CLIST(clist), 0, 0);
  return;
}

/******loop to draw curve******/

gboolean draw_cpu_curve(gpointer widget){
  GtkWidget *cpu_curve = (GtkWidget *)widget;
  GdkColor color;
  GdkGC *gc = cpu_curve->style->fg_gc[GTK_WIDGET_STATE(widget)];
  static int flag = 0;
  static int now_pos = 0;
  int draw_pos = 0;

  /* Darw background */
  color.red = 0;
  color.green = 0;
  color.blue = 0;
  gdk_gc_set_rgb_fg_color(gc, &color);
  gdk_draw_rectangle(cpu_curve->window, gc, TRUE, 15, 30, 480, 200);

  /* Draw background lines */
  color.red = 0;
  color.green = 20000;
  color.blue = 0;
  gdk_gc_set_rgb_fg_color(gc, &color);
  for (int i = 30; i <= 220; i += 20)
    gdk_draw_line(cpu_curve->window, gc, 15, i, 495, i);
  for (int i = 15; i <= 480; i += 20)
    gdk_draw_line(cpu_curve->window, gc, i + cpu_curve_start, 30, i + cpu_curve_start, 230);

  /* Settle cpu curve start position to make it live */
  cpu_curve_start -= 4;
  if (cpu_curve_start == 0)
    cpu_curve_start = 20;

  /* Initial data */
  if (flag == 0) {
    for (int i = 0; i < 120; i++) {
      cpu_ratio_data[i] = 0;
      flag = 1;
    }
  }

  /* Add data */
  cpu_ratio_data[now_pos] = cpu_ratio / 100;
  now_pos++;
  if (now_pos == 120)
    now_pos = 0;
    
  /* Draw lines */
  color.red = 0;
	color.green = 65535;
	color.blue = 0;
	gdk_gc_set_rgb_fg_color(gc, &color);
  draw_pos = now_pos;
  for (int i = 0; i < 119; i++) {
    gdk_draw_line(cpu_curve->window, gc,
                  15 + i * 4, 230 - 200 * cpu_ratio_data[draw_pos % 120],
                  15 + (i + 1) * 4, 230 - 200 * cpu_ratio_data[(draw_pos + 1) % 120]);
    draw_pos++;
    if (draw_pos == 120)
      draw_pos = 0;
  }

  /* Reset the color */
  color.red = 25000;
	color.green = 25000;
	color.blue = 25000;
	gdk_gc_set_rgb_fg_color(gc, &color);

  /* To loop this function, it must return TRUE */
  return TRUE;
}


